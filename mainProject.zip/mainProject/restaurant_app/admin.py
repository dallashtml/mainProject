from django.contrib import admin
from django.contrib.auth.models import User
from .models import Category, Dish, Order, QuizResult, Profile

admin.site.register(Category)
admin.site.register(Dish)
admin.site.register(QuizResult)
admin.site.register(Profile)

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('dish', 'customer_name', 'table_number', 'created_at')
    list_filter = ('dish', 'created_at')
    search_fields = ('customer_name', 'table_number', 'dish__name')
