// Регистрация Service Worker для push-уведомлений
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/static/restaurant_app/js/service-worker.js')
    .then(function(registration) {
        console.log('Service Worker зарегистрирован с областью:', registration.scope);
    })
    .catch(function(error) {
        console.error('Ошибка регистрации Service Worker:', error);
    });
}

// Пример функции для запроса разрешения на показ уведомлений
function requestNotificationPermission() {
    if ('Notification' in window) {
        Notification.requestPermission().then(function(permission) {
            if (permission === 'granted') {
                console.log('Разрешение на уведомления получено.');
                // Здесь можно отправить запрос на сервер для регистрации push-подписки
            }
        });
    }
}

// Запрос разрешения при загрузке страницы
document.addEventListener('DOMContentLoaded', requestNotificationPermission);
