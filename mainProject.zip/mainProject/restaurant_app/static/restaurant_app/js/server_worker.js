self.addEventListener('push', function(event) {
    let data = {};
    if (event.data) {
        data = event.data.json();
    }

    const title = data.title || 'Новое уведомление от Food & Mood!';
    const options = {
        body: data.body || 'Узнайте о наших специальных предложениях!',
        icon: '/static/restaurant_app/images/icon.png',  // Добавьте свой значок
        badge: '/static/restaurant_app/images/badge.png'
    };

    event.waitUntil(
        self.registration.showNotification(title, options)
    );
});

self.addEventListener('notificationclick', function(event) {
    event.notification.close();
    // При клике можно открыть определённую страницу
    event.waitUntil(
        clients.openWindow('/')
    );
});
