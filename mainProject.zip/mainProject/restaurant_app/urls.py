from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.views.generic import TemplateView
from .views import register, user_login
from django.contrib.auth.views import LogoutView

app_name = 'restaurant_app'

urlpatterns = [
    path('', views.index, name='index'),
    path('menu/', views.menu, name='menu'),
    path('order/<int:dish_id>/', views.order_dish, name='order_dish'),
    path('order/success/', views.order_success, name='order_success'),
    path('order/cart/<int:dish_id>/', views.add_to_cart, name='add_to_cart'),
    path('order/cancel/<int:order_id>/', views.cancel_order, name='cancel_order'),
    path('basket/', views.basket, name='basket'),

    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='restaurant_app:index'), name='logout'),

    # Страница заказов (если есть)
    path('orders/', views.my_orders, name='orders'),

    path('quiz/', views.quiz, name='quiz'),

    path('chatbot/', TemplateView.as_view(template_name='restaurant_app/chatbot.html'), name='chatbot'),
    path('verify-phone/', views.phone_verification, name='phone_verification'),

]

