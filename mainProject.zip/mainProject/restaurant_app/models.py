from django.db import models
from django.contrib.auth.models import User
from django.conf import settings

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)

    class Meta:
        verbose_name_plural = "Категории"

    def __str__(self):
        return self.name

class Dish(models.Model):
    category = models.ForeignKey(Category, related_name='dishes', on_delete=models.CASCADE)
    name = models.CharField(max_length=150)
    description = models.TextField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    image = models.ImageField(upload_to='dishes/', blank=True, null=True)

    def __str__(self):
        return self.name


class Order(models.Model):
    STATUS_CHOICES = [
        ('cart', 'В корзине'),
        ('accepted', 'Принят'),
        ('preparing', 'Готовится'),
        ('cancelled', 'Отменён'),
        ('completed', 'Завершён'),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True)
    dish = models.ForeignKey('Dish', related_name='orders', on_delete=models.CASCADE)
    customer_name = models.CharField(max_length=100)
    table_number = models.CharField(max_length=10)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='cart')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Заказ {self.dish.name} для {self.customer_name} (стол: {self.table_number}) - {self.get_status_display()}"







# Дополнительная информация о пользователе (номер телефона)
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=20, blank=True, verbose_name="Номер телефона")

    def __str__(self):
        return f"{self.user.username} ({self.phone_number})"


# Модель для хранения результатов викторины
class QuizResult(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quiz_results')
    score = models.IntegerField(verbose_name="Результат")
    date_taken = models.DateTimeField(auto_now_add=True, verbose_name="Дата прохождения")
    def __str__(self):
        return f"{self.user.username}: {self.score} баллов ({self.date_taken.strftime('%Y-%m-%d')})"

# Новая модель для хранения деталей викторины
class QuizDetail(models.Model):
    quiz_result = models.ForeignKey(QuizResult, on_delete=models.CASCADE, related_name='details')
    question_number = models.IntegerField()
    question_text = models.TextField(blank=True)
    correct_answer = models.CharField(max_length=50)
    selected_answer = models.CharField(max_length=50)
    is_correct = models.BooleanField()

    def __str__(self):
        return f"Вопрос {self.question_number}: {'Правильно' if self.is_correct else 'Неправильно'}"