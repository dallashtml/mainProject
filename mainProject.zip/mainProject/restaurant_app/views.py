from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.conf import settings
import os
import json

from .models import Category, Dish, QuizResult, QuizDetail, Profile, Order
from .forms import OrderForm, RegistrationForm


def index(request):
    categories = Category.objects.all()
    context = {
        'categories': categories,
    }
    return render(request, 'restaurant_app/index.html', context)

def menu(request):
    dishes = Dish.objects.select_related('category').all()
    context = {
        'dishes': dishes,
    }
    return render(request, 'restaurant_app/menu.html', context)


###


#################################################################
@login_required
def order_dish(request, dish_id):
    dish = get_object_or_404(Dish, id=dish_id)
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.dish = dish
            order.user = request.user  # <-- Обязательно устанавливаем залогиненного пользователя
            order.status = 'accepted'  # Можно сразу задать статус, например, "Принят"
            order.save()
            messages.success(request, "Заказ успешно оформлен!")
            return redirect('restaurant_app:order_success')
        else:
            messages.error(request, "Ошибка формы. Пожалуйста, проверьте данные.")
    else:
        form = OrderForm()
    return render(request, 'restaurant_app/order_form.html', {'form': form, 'dish': dish})

#######################################################

def order_success(request):
    return render(request, 'restaurant_app/order_success.html')


# Представление для входа
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')

        verification_code = request.POST.get('verification_code')

        # Код тексеру кезеңі
        if 'verification_code' in request.POST:
            expected_code = request.session.get('verification_code')
            if verification_code == expected_code:
                user = authenticate(request, username=username, password=password)
                if user:
                    login(request, user)
                    return redirect('restaurant_app:index')
                else:
                    return render(request, 'restaurant_app/login.html', {'error': 'Логин немесе пароль қате.'})
            else:
                return render(request, 'restaurant_app/login.html', {'error': 'Код дұрыс емес.', 'show_code': True})

        # Алдымен телефон номер және логин сәйкестігін тексеру
        try:
            user_profile = Profile.objects.get(user__username=username)
            if user_profile.phone_number == phone_number:
                # Код генерация
                code = str(random.randint(1000, 9999))
                request.session['verification_code'] = code
                request.session['username'] = username
                request.session['password'] = password

                return render(request, 'restaurant_app/login.html', {
                    'show_code': True,
                    'generated_code': code  # экранға код шығару үшін
                })
            else:
                return render(request, 'restaurant_app/login.html', {'error': 'Телефон нөмір дұрыс емес.'})
        except Profile.DoesNotExist:
            return render(request, 'restaurant_app/login.html', {'error': 'Профиль табылған жоқ.'})

    return render(request, 'restaurant_app/login.html')


# Представление для регистрации
def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            phone = form.cleaned_data.get('phone')
            Profile.objects.create(user=user, phone_number=phone)
            login(request, user)

            # Сохраняем регистрационные данные в JSON-файл
            registration_data = {
                "username": user.username,
                "email": user.email,
                "phone": phone,
                "date_registered": str(user.date_joined)
            }
            json_file = os.path.join(settings.BASE_DIR, 'registrations.json')
            if os.path.exists(json_file):
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                data = []
            data.append(registration_data)
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            return redirect('restaurant_app:index')
        else:
            messages.error(request, form.errors)
    else:
        form = RegistrationForm()
    return render(request, 'restaurant_app/register.html', {'form': form})


# Представление для выхода
def user_logout(request):
    logout(request)
    return redirect('restaurant_app:index')



# Представление викторины (только для авторизованных пользователей)
@login_required
def quiz(request):
    if request.method == 'POST':
        score = int(request.POST.get('score', 0))
        details_json = request.POST.get('details', '[]')
        try:
            details = json.loads(details_json)
        except json.JSONDecodeError:
            details = []
        quiz_result = QuizResult.objects.create(user=request.user, score=score)
        for detail in details:
            QuizDetail.objects.create(
                quiz_result=quiz_result,
                question_number=detail.get('question_number'),
                question_text=detail.get('question_text', ''),
                correct_answer=detail.get('correct_answer'),
                selected_answer=detail.get('selected_answer'),
                is_correct=detail.get('is_correct', False)
            )
        return render(request, 'restaurant_app/quiz_success.html', {'score': score})
    return render(request, 'restaurant_app/quiz.html')




@login_required
def add_to_cart(request, dish_id):
    dish = get_object_or_404(Dish, id=dish_id)
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.dish = dish
            order.user = request.user
            order.status = 'cart'  # заказ добавляется в корзину
            order.save()
            messages.success(request, "Заказ добавлен в корзину.")
            return redirect('restaurant_app:menu')
    else:
        form = OrderForm()
    return render(request, 'restaurant_app/order_form.html', {'form': form, 'dish': dish})


@login_required
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if order.status not in ['cancelled', 'completed']:
        order.status = 'cancelled'
        order.save()
        messages.info(request, "Заказ отменён.")
    else:
        messages.warning(request, "Невозможно отменить заказ.")
    return redirect('restaurant_app:orders')  # предполагается, что у вас есть страница с заказами


@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'restaurant_app/orders.html', {'orders': orders})

@login_required
def basket(request):
    # Выбираем заказы текущего пользователя, где статус равен "cart"
    orders = Order.objects.filter(user=request.user, status='cart')
    return render(request, 'restaurant_app/basket.html', {'orders': orders})


import random
from django.contrib import messages


def phone_verification(request):
    if request.method == 'POST':
        phone_number = request.POST.get('phone_number')
        input_code = request.POST.get('code')

        if 'verification_code' in request.session:
            # Код тексеру
            if input_code == request.session['verification_code']:
                messages.success(request, 'Телефон нөмірі сәтті расталды!')
                del request.session['verification_code']
                return redirect('restaurant_app:index')
            else:
                messages.error(request, 'Қате код! Қайта тексеріңіз.')

        else:
            # Бірінші рет код жіберу (симуляция)
            verification_code = str(random.randint(1000, 9999))
            request.session['verification_code'] = verification_code
            messages.info(request, f'Кодыңыз: {verification_code} (Бұл жерде SMS сияқты көрінеді)')

    return render(request, 'restaurant_app/phone_verification.html')
